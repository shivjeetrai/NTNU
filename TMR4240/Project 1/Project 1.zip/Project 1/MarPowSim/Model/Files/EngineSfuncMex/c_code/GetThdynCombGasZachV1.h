/*
 * GetThdynCombGasZachV1.h
 *
 * Code generation for function 'GetThdynCombGasZachV1'
 *
 * C source code generated on: Tue Oct 07 15:50:29 2014
 *
 */

#ifndef __GETTHDYNCOMBGASZACHV1_H__
#define __GETTHDYNCOMBGASZACHV1_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>


/* Function Declarations */
extern void GetThdynCombGasZachV1(real_T P, real_T T, real_T F, real_T fs, real_T *R, real_T *h, real_T *s, real_T *u, real_T *RF, real_T *RP, real_T *RT, real_T *uF, real_T *uP, real_T *uT, real_T *sF, real_T *sP, real_T *sT, real_T *Cp, real_T *Cv, real_T *K);
#endif
/* End of code generation (GetThdynCombGasZachV1.h) */
