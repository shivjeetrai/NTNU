/*
 * GetThdynCombGasZach.h
 *
 * Code generation for function 'GetThdynCombGasZach'
 *
 * C source code generated on: Tue Mar 25 11:39:08 2014
 *
 */

#ifndef __GETTHDYNCOMBGASZACH_H__
#define __GETTHDYNCOMBGASZACH_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"

/* Function Declarations */
#ifdef __cplusplus
extern "C" {
#endif
extern void GetThdynCombGasZach(real_T P, real_T T, real_T F, real_T *R, real_T *h, real_T *s, real_T *u, real_T *RF, real_T *RP, real_T *RT, real_T *uF, real_T *uP, real_T *uT, real_T *Cp, real_T *Cv, real_T *K);
#ifdef __cplusplus
}
#endif
#endif
/* End of code generation (GetThdynCombGasZach.h) */
