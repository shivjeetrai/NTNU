clear all;
initProject1
controlGainsDP
%sim('project_1')
%plotF