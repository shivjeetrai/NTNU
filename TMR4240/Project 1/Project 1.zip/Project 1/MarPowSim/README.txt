See "How to build a model.docx"


